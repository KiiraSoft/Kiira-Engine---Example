//This Javscript file modifies the library, adding in the autocompletion to the search bar, and the style for the dropdown grouping of nodes. 

//This script adds in the autocompletion feature for the text box: 
